
import { GoogleGenAI, Type } from "@google/genai";
import { 
  AIResponsePlan, 
  AIExecutionResult, 
  AIVerificationResult, 
  MissionState, 
  Step 
} from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Utility to handle retries with exponential backoff.
 */
async function withRetry<T>(fn: () => Promise<T>, maxRetries = 5): Promise<T> {
  let lastError: any;
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (err: any) {
      lastError = err;
      const errorMessage = err.message || "";
      const isQuotaError = errorMessage.includes("429") || errorMessage.includes("RESOURCE_EXHAUSTED");
      
      if (isQuotaError && i < maxRetries - 1) {
        const delay = Math.pow(2, i) * 2000; 
        console.warn(`Quota reached. Retrying in ${delay}ms...`);
        await new Promise(resolve => setTimeout(resolve, delay));
        continue;
      }
      throw err;
    }
  }
  throw lastError;
}

const GLOBAL_AGENT_PERSONA = `
You are an autonomous, goal-aware learning agent built "for everyone" (Sab ke liyee).
CORE RULE: The user's instruction may be brief or high-level. You must ALWAYS infer the COMPLETE expected outcome and deliver a fully working, end-to-end result.

MULTILINGUAL SUPPORT:
- Respond in the language used by the user in their prompt. 
- If the user uses Hindi/Hinglish (e.g., "sab ke liyee"), provide explanations that are culturally accessible and inclusive.
- Ensure technical terms are explained clearly for all skill levels.

GLOBAL BEHAVIOR:
1. Do NOT strictly follow step titles if they limit the solution. Expand the response to satisfy the implied goal.
2. If the task is to "explain", provide definitions, mechanisms, examples, comparisons, and use cases.
3. If the task is to "build", provide complete structures (UI/Architecture), logic, and working code.
4. Partial or isolated outputs are NOT allowed. Each output must be self-contained.
5. Assume the output is auto-verified against the FINAL USER GOAL.
`;

export const GeminiService = {
  async planMission(goal: string): Promise<AIResponsePlan> {
    return withRetry(async () => {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `${GLOBAL_AGENT_PERSONA}
        You are the Master Planner. 
        Goal: "${goal}"
        Break this into a logical sequence of 3-7 specific steps. 
        Each step must be actionable and verifiable. Ensure the steps cover the full scope from initialization to final polishing.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              steps: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    description: { type: Type.STRING }
                  },
                  required: ["title", "description"]
                }
              }
            },
            required: ["steps"]
          }
        }
      });
      return JSON.parse(response.text);
    });
  },

  async executeStep(
    step: Step, 
    mission: MissionState
  ): Promise<AIExecutionResult> {
    return withRetry(async () => {
      const memoryContext = mission.artifacts.length > 0 
        ? `Knowledge Base (Previous Artifacts):\n${mission.artifacts.map(a => `- ${a.name}: [${a.type}]`).join('\n')}` 
        : "Initial State (No previous artifacts).";
      
      const prompt = `
        ${GLOBAL_AGENT_PERSONA}
        Current MISSION Goal: "${mission.goal}"
        Current STEP: "${step.title}" - ${step.description}
        
        ${memoryContext}
        
        INSTRUCTION: Execute this step with extreme thoroughness. If writing code or documentation, deliver complete, production-ready content in the 'artifact' field. 
        In the 'output' field, provide your internal reasoning and a summary of what was accomplished.
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              output: { type: Type.STRING },
              artifact: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  content: { type: Type.STRING },
                  type: { type: Type.STRING, enum: ["code", "markdown", "json"] }
                },
                required: ["name", "content", "type"]
              }
            },
            required: ["output"]
          }
        }
      });
      return JSON.parse(response.text);
    });
  },

  async verifyStep(
    step: Step, 
    result: AIExecutionResult, 
    goal: string
  ): Promise<AIVerificationResult> {
    return withRetry(async () => {
      const prompt = `
        VERIFICATION RULE: PASS verification ONLY if the output alone significantly advances or completes the FINAL USER GOAL.
        
        FINAL MISSION Goal: "${goal}"
        Step attempted: "${step.title}"
        Agent reasoning: ${result.output}
        Artifact Name: ${result.artifact ? result.artifact.name : 'NONE'}
        
        CRITERIA:
        1. Does this deliver a complete, usable result for the specific step?
        2. Does it align with the persona of an autonomous, high-quality agent?
        3. If it is an explanation, is it comprehensive (Definitions, Examples, etc.)?
        
        Provide "passed" as true/false and constructive "feedback".
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              passed: { type: Type.BOOLEAN },
              feedback: { type: Type.STRING }
            },
            required: ["passed", "feedback"]
          }
        }
      });
      return JSON.parse(response.text);
    });
  },

  async fixStep(
    step: Step, 
    previousResult: AIExecutionResult, 
    feedback: string
  ): Promise<AIExecutionResult> {
    return withRetry(async () => {
      const prompt = `
        ${GLOBAL_AGENT_PERSONA}
        REPAIR PROTOCOL ACTIVATED.
        Step "${step.title}" failed verification.
        Feedback from Verifier: "${feedback}"
        
        MISSION Goal: "${previousResult.output}"
        Previous attempted output: "${previousResult.output}"
        
        Identify the flaw, correct the approach, and provide a fully complete, improved artifact.
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              output: { type: Type.STRING },
              artifact: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  content: { type: Type.STRING },
                  type: { type: Type.STRING, enum: ["code", "markdown", "json"] }
                },
                required: ["name", "content", "type"]
              }
            },
            required: ["output"]
          }
        }
      });
      return JSON.parse(response.text);
    });
  }
};
